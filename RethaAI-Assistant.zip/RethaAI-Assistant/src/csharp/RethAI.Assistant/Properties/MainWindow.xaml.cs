using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System.Threading.Tasks;

namespace RethAI.Assistant
{
    public partial class MainWindow : Window
    {
        private VoiceModulationService voiceService;
        private AICoreService aiCore;
        private DispatcherTimer responseTimer;
        private Queue<string> responseQueue;

        public MainWindow()
        {
            InitializeComponent();
            InitializeServices();
            InitializeTimer();
            AddSystemMessage("🚀 RETHAI ASSISTANT - C# Edition Activated");
        }

        private void InitializeServices()
        {
            voiceService = new VoiceModulationService();
            aiCore = new AICoreService();
            responseQueue = new Queue<string>();
        }

        private void InitializeTimer()
        {
            responseTimer = new DispatcherTimer();
            responseTimer.Interval = TimeSpan.FromMilliseconds(100);
            responseTimer.Tick += ProcessResponseQueue;
            responseTimer.Start();
        }

        private void ProcessResponseQueue(object sender, EventArgs e)
        {
            if (responseQueue.Count > 0)
            {
                var response = responseQueue.Dequeue();
                AddMessage("RETHAI", response, "ai");
                UpdateStatus("🟢 SYSTEM: Ready for commands");
            }
        }

        private void AddSystemMessage(string message)
        {
            AddMessage("SYSTEM", message, "system");
        }

        private void AddMessage(string sender, string message, string type)
        {
            Dispatcher.Invoke(() =>
            {
                var timestamp = DateTime.Now.ToString("HH:mm:ss");
                var messageText = $"[{timestamp}] {sender}: {message}\n";

                var textBlock = new TextBlock
                {
                    Text = messageText,
                    FontFamily = new FontFamily("Consolas"),
                    FontSize = 12,
                    Margin = new Thickness(0, 2, 0, 2)
                };

                // Set colors based on message type
                switch (type)
                {
                    case "system":
                        textBlock.Foreground = Brushes.Orange;
                        break;
                    case "user":
                        textBlock.Foreground = Brushes.White;
                        break;
                    case "ai":
                        textBlock.Foreground = Brushes.Lime;
                        break;
                }

                ChatDisplay.Children.Add(textBlock);
                ScrollViewer.ScrollToEnd();
            });
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            await ProcessUserInput();
        }

        private async void UserInput_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                await ProcessUserInput();
            }
        }

        private async Task ProcessUserInput()
        {
            var userText = UserInput.Text.Trim();
            if (string.IsNullOrEmpty(userText)) return;

            AddMessage("USER", userText, "user");
            UserInput.Clear();
            UpdateStatus("🟡 SYSTEM: Processing AI response...");

            // Process in background
            await Task.Run(() => GenerateAIResponse(userText));
        }

        private void GenerateAIResponse(string query)
        {
            try
            {
                var language = GetSelectedLanguage();
                var voiceType = GetSelectedVoice();
                
                var response = aiCore.ProcessQuery(query, language);
                var modulatedResponse = voiceService.Modulate(response, voiceType);
                
                responseQueue.Enqueue(modulatedResponse);
            }
            catch (Exception ex)
            {
                responseQueue.Enqueue($"❌ ERROR: {ex.Message}");
            }
        }

        private string GetSelectedLanguage()
        {
            if (PythonRadio.IsChecked == true) return "python";
            if (JavaScriptRadio.IsChecked == true) return "javascript";
            return "csharp";
        }

        private string GetSelectedVoice()
        {
            return VoiceComboBox.SelectedValue?.ToString() ?? "cosmic";
        }

        private void UpdateStatus(string status)
        {
            Dispatcher.Invoke(() =>
            {
                StatusText.Text = status;
            });
        }

        private void VoiceComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var newVoice = GetSelectedVoice();
            AddSystemMessage($"Voice mode changed to: {newVoice.ToUpper()}");
        }
    }
}