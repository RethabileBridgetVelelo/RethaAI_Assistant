using System;
using System.Collections.Generic;
using System.Linq;

namespace RethAI.Assistant.Services
{
    public class VoiceModulationService
    {
        private Dictionary<string, Func<string, string>> voices;
        private Random random;

        public VoiceModulationService()
        {
            random = new Random();
            InitializeVoices();
        }

        private void InitializeVoices()
        {
            voices = new Dictionary<string, Func<string, string>>
            {
                ["cosmic"] = CosmicVoice,
                ["neural"] = NeuralVoice,
                ["quantum"] = QuantumVoice,
                ["cyber"] = CyberVoice
            };
        }

        private string CosmicVoice(string text)
        {
            var words = text.Split(' ');
            var modulated = words.Select(word => 
                random.NextDouble() > 0.7 ? $"⚡{word.ToUpper()}⚡" : word
            );
            return $"🌌 COSMIC: {string.Join(" ", modulated)}";
        }

        private string NeuralVoice(string text)
        {
            return $"🧠 NEURAL: {text} :: Processing Complete";
        }

        private string QuantumVoice(string text)
        {
            var parts = text.Split(' ').ToList();
            if (parts.Count > 2)
            {
                parts.Insert(random.Next(1, parts.Count - 1), "🔮");
            }
            return $"🌀 QUANTUM: {string.Join(" ", parts)}";
        }

        private string CyberVoice(string text)
        {
            var cyberTerms = new[] { "[SYSTEM]", "[PROTOCOL]", "[EXECUTE]", "[ACCESS]" };
            var term = cyberTerms[random.Next(cyberTerms.Length)];
            return $"💻 CYBER: {term} {text} {term}";
        }

        public string Modulate(string text, string voiceType = "cosmic")
        {
            if (voices.ContainsKey(voiceType))
            {
                return voices[voiceType](text);
            }
            return text; // Fallback to unmodulated text
        }

        public List<string> GetAvailableVoices()
        {
            return voices.Keys.ToList();
        }
    }
}