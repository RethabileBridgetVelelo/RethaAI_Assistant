using System;
using System.Collections.Generic;
using System.Linq;
using RethAI.Assistant.Models;

namespace RethAI.Assistant.Services
{
    public class AICoreService
    {
        private Dictionary<string, List<string>> responsePatterns;
        private List<ConversationItem> conversationHistory;
        private Random random;

        public AICoreService()
        {
            random = new Random();
            conversationHistory = new List<ConversationItem>();
            InitializeResponsePatterns();
        }

        private void InitializeResponsePatterns()
        {
            responsePatterns = new Dictionary<string, List<string>>
            {
                ["python"] = new List<string>
                {
                    "Python Analysis: Neural network optimization in progress...",
                    "🐍 TensorFlow session active. Deploying AI models...",
                    "Python Core: Multi-threaded inference engine engaged.",
                    "Data Science Module: Processing complex algorithms...",
                    "Machine Learning: Training neural networks complete."
                },
                ["javascript"] = new List<string>
                {
                    "JavaScript Engine: Node.js runtime initializing...",
                    "🌐 V8 Optimization: Async computations executing...",
                    "WebAI: Browser-based neural networks active.",
                    "React AI: Component intelligence systems online.",
                    "TypeScript Core: Type-safe AI processing engaged."
                },
                ["csharp"] = new List<string>
                {
                    "C# Framework: .NET ML.NET services starting...",
                    "💼 Enterprise AI: Secure protocols activated.",
                    "Unity Integration: 3D neural visualization ready.",
                    "ASP.NET Core: Web API intelligence deployed.",
                    "Xamarin AI: Cross-platform mobile intelligence active."
                }
            };
        }

        public string ProcessQuery(string query, string language)
        {
            // Simulate processing delay
            System.Threading.Thread.Sleep(800);

            if (!responsePatterns.ContainsKey(language))
            {
                language = "python"; // Default fallback
            }

            var responses = responsePatterns[language];
            var baseResponse = responses[random.Next(responses.Count)];

            // Store in history
            var conversationItem = new ConversationItem
            {
                Query = query,
                Response = baseResponse,
                Language = language,
                Timestamp = DateTime.Now
            };
            conversationHistory.Add(conversationItem);

            return $"{baseResponse} | Query: '{query}'";
        }

        public List<ConversationItem> GetConversationHistory()
        {
            return new List<ConversationItem>(conversationHistory);
        }

        public void ClearHistory()
        {
            conversationHistory.Clear();
        }
    }
}