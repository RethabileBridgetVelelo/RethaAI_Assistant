# 💼 RETHAI ASSISTANT - C# Edition

## 🚀 Features
- **WPF Desktop Application** - Native Windows experience
- **.NET 5.0** - Modern C# framework
- **Enterprise Architecture** - Clean MVVM-ready structure
- **Dark Professional UI** - Consistent with other editions

## 🛠️ Requirements
- **.NET 5.0 SDK** or higher
- **Visual Studio 2019/2022** or **VS Code with C# extension**

## 🔧 Building
```bash
# Using .NET CLI
dotnet build
dotnet run

# Or open in Visual Studio
RethAI.Assistant.sln