using System;

namespace RethAI.Assistant.Models
{
    public class ConversationItem
    {
        public string Query { get; set; }
        public string Response { get; set; }
        public string Language { get; set; }
        public DateTime Timestamp { get; set; }
    }
}